(async() => {
    await
    import ('./app.mjs');
})();